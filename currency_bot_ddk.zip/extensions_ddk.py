import json
import requests
from config_ddk import exchanges, API_KEY

class APIException(Exception):
    pass


class Convertor:
    @staticmethod
    def get_price(base, sym, amount):
        try:
            base_key = exchanges[base.lower()]
        except KeyError:
            raise APIException(f"Валюта {base} не найдена!")

        try:
            sym_key = exchanges[sym.lower()]
        except KeyError:
            raise APIException(f"Валюта {sym} не найдена!")

        if base_key == sym_key:
            raise APIException(f'Невозможно перевести одинаковые валюты {base}!')
        
        try:
            amount = float(amount)
        except ValueError:
            raise APIException(f'Не удалось обработать количество {amount}!')
        
        url = f"https://api.apilayer.com/currency_data/convert?to={sym_key}&from={base_key}&amount={amount}"
        payload = {}
        headers= {
            "apikey": API_KEY
        }
        response = requests.request("GET", url, headers=headers, data = payload)
        status_code = response.status_code
        result = response.text
        resp2 = json.loads(result)
        new_price = resp2['result']
        message =  f"Цена {amount} {base} в {sym} : {new_price}"
        return message