BOT_TOKEN = "6111958717:AAH26H6vY4kX41InGOjwnQO6_jfAQV5y6Eg"
API_KEY = "sC8tUjIVifD6MOuurrvkt8Rvii7da8Qq"
exchanges = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB',
    'юань': 'CNY',
    'вона': 'KRW'
}
