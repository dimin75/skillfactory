URL to access pages:
http://127.0.0.1:8000/ (default - the others is available from here)
http://127.0.0.1:8000/page1/
http://127.0.0.1:8000/page2/
http://127.0.0.1:8000/page3/
http://127.0.0.1:8000/admin_page/
superuser login: admin
superuser password: admin